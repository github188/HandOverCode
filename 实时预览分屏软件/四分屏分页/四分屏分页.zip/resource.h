//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by CFourPic.rc
//
#define IDM_ABOUTBOX                    0x0010
#define IDD_ABOUTBOX                    100
#define IDS_ABOUTBOX                    101
#define IDD_CFOURPIC_DIALOG             102
#define IDR_MAINFRAME                   128
#define IDD_DLGPLAY                     129
#define IDR_MENU1                       130
#define IDC_STATIC_WND1                 1000
#define IDC_STATIC_WND2                 1001
#define IDC_WNDMIN                      1001
#define IDC_STATIC_WND3                 1002
#define IDC_BTNQH                       1002
#define IDC_STATIC_WND4                 1003
#define IDC_BTNJT                       1003
#define IDC_STATIC_WND5                 1004
#define IDC_BTNDJ                       1004
#define IDC_STATIC_WND6                 1005
#define IDC_STATIC_MSG                  1005
#define IDC_STATIC_WND7                 1006
#define IDC_BTNPageUP                   1007
#define IDC_BTNPageDown                 1008
#define IDC_STATIC_PAGE                 1009
#define IDM_MREALPLAY                   32771
#define IDM_MVOICECOM                   32772
#define IDM_EXIT                        32773
#define IDM_MSWITCH                     32774
#define IDM_MSOUNDSHARE                 32775
#define IDM_MSTARTALL                   32776
#define ID_MENUITEM32778                32778
#define IDM_RGPPDLL                     32779

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32780
#define _APS_NEXT_CONTROL_VALUE         1010
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
